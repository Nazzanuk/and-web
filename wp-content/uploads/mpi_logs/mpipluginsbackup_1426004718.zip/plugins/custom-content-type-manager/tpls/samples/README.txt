Don't touch these! They are used in the manager to demonstrate sample HTML, PHP, or CSS 
for a particular custom content type.

If you are looking for where you should create a custom manager template, look in
tpls/manager instead.

Thanks.