<?php
/**
 * Run tests as done when the plugin is first activated.
 */

/*EOF*/