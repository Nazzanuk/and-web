=== Multi Plugin Installer===
Contributors: rahulbrilliant2004, tikendramaitry
Donate link: http://www.wpfruits.com
Tags: bulk plugin installer, multiple plugin installer, plugin centra, export plugins, import plugins
Requires at least: 3.0
Tested up to: 3.9
Stable tag: 1.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

You can install multiple plugins in one go with Multi Plugin Installer plugin.

== Description ==
This great plugin allows you to install multiple plugins at a time rather than going through a process of searching, installing and activating multiple plugins. All you need to do it put the names/url/path-to-zip of the plugin the text box and press install button and all those plugins will be installed for you. 

This plugin all allows you to install multiple plugins from your local computer by selecting them all together and installing them in one go. 

Multi Plugin Installer also allows you to export the mpi file and import it on another WordPress installation so that you can get all the plugins installed there too. 

Multi Plugin Installer allows you to take a backup of all the plugins and install it on another WordPress installation in one go. 

Click here to know more about how to use the plugin <a href="http://www.wpfruits.com/downloads/wp-plugins/multi-plugin-installer/">http://www.wpfruits.com/downloads/wp-plugins/multi-plugin-installer/</a>



=Features  =
This great plugin allows you to install multiple plugins at a time rather than going through a process of searching, installing and activating multiple plugins. All you need to do it put the names/url/path-to-zip of the plugin the text box and press install button and all those plugins will be installed for you. 

This plugin all allows you to install multiple plugins from your local computer by selecting them all together and installing them in one go. 

Multi Plugin Installer also allows you to export the mpi file and import it on another WordPress installation so that you can get all the plugins installed there too. 

Multi Plugin Installer allows you to take a backup of all the plugins and install it on another WordPress installation in one go. 

Click here to know more about how to use the plugin <a href="http://www.wpfruits.com/downloads/wp-plugins/multi-plugin-installer/">http://www.wpfruits.com/downloads/wp-plugins/multi-plugin-installer/</a>


== Installation ==
    Upload the plugin folder to the /wp-content/plugins/ folder of your WordPress installation.
    Activate the plugin. 
    You will see an option at the left bottom of the WordPress options in the left sidebar.
    Click on it to set the options
    Get going�

Click here to know more about how to use the plugin <a href="http://www.wpfruits.com/downloads/wp-plugins/multi-plugin-installer/">http://www.wpfruits.com/downloads/wp-plugins/multi-plugin-installer/</a>


== Frequently asked questions ==

= A question that someone might have =
Click here to know more about how to use the plugin <a href="http://www.wpfruits.com/downloads/wp-plugins/multi-plugin-installer/">http://www.wpfruits.com/downloads/wp-plugins/multi-plugin-installer/</a>

== Screenshots ==
1. The settings page.


== Changelog ==

= Version 1.1.0 =

* Fixed few warning issues in plugin admin settings.
* Compatible with the WordPress latest version (3.9).

= Version 1.0.0 =

* Initial release

== Upgrade notice ==
For better performance please upgrade quickly.

== Arbitrary section 1 ==