<a href="https://servmask.com/extensions/backup-to-dropbox" target="_blank"><?php _e( 'Dropbox', AI1WM_PLUGIN_NAME ); ?></a>
