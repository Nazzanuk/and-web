<a href="https://servmask.com/extensions/backup-to-amazon-s3" target="_blank"><?php _e( 'Amazon S3', AI1WM_PLUGIN_NAME ); ?></a>
